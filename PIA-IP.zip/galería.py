
from PIL import Image
def galeria():
  imagen = Image.open(r"Canelo-1.png")
  imagen.show()
  
  imagen = Image.open(r"Canelo-2.png")
  imagen.show()